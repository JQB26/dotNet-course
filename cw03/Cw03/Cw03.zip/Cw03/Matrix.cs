﻿using System;

namespace Cw03
{
    public class Matrix<T> where T : IComparable, IFormatProvider
    {

    }
}