﻿using System;

namespace Cw03
{
    class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
